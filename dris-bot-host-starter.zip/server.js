require("dotenv").config();
const express = require("express");
const session = require("express-session");
const crypto = require("crypto");
const path = require("path");

const app = express();
const PORT = process.env.PORT || 3000;
const settings = {
  botName: process.env.BOT_NAME || "DRIS BOT",
  prefix: process.env.BOT_PREFIX || "-",
  language: process.env.BOT_LANGUAGE || "English"
};

app.use(express.json({ verify: (req, res, buf) => { req.rawBody = buf; } }));
app.use(express.urlencoded({ extended: true }));
app.use(session({
  secret: process.env.SESSION_SECRET || "development-only-change-me",
  resave: false,
  saveUninitialized: false,
  cookie: { httpOnly: true, sameSite: "lax", secure: process.env.NODE_ENV === "production" }
}));
app.use(express.static(path.join(__dirname, "public")));

const isLoggedIn = (req, res, next) => req.session.loggedIn ? next() : res.status(401).json({ error: "Please log in." });

app.post("/api/login", (req, res) => {
  const { username, password } = req.body || {};
  if (username === (process.env.ADMIN_USERNAME || "admin") &&
      password === (process.env.ADMIN_PASSWORD || "change-this-password")) {
    req.session.loggedIn = true;
    return res.json({ ok: true });
  }
  res.status(401).json({ error: "Incorrect username or password." });
});
app.post("/api/logout", (req, res) => req.session.destroy(() => res.json({ ok: true })));
app.get("/api/status", isLoggedIn, (req, res) => res.json({
  running: Boolean(process.env.META_PAGE_ACCESS_TOKEN),
  connected: Boolean(process.env.META_PAGE_ACCESS_TOKEN),
  settings
}));
app.post("/api/settings", isLoggedIn, (req, res) => {
  const { botName, prefix, language } = req.body || {};
  if (typeof botName === "string" && botName.trim()) settings.botName = botName.trim().slice(0, 40);
  if (typeof prefix === "string" && prefix.trim()) settings.prefix = prefix.trim().slice(0, 5);
  if (typeof language === "string") settings.language = language.slice(0, 30);
  res.json({ ok: true, settings });
});

// Meta Messenger webhook verification
app.get("/webhook", (req, res) => {
  const mode = req.query["hub.mode"];
  const token = req.query["hub.verify_token"];
  const challenge = req.query["hub.challenge"];
  if (mode === "subscribe" && token && token === process.env.META_VERIFY_TOKEN) {
    return res.status(200).send(challenge);
  }
  res.sendStatus(403);
});

async function sendMessage(recipientId, text) {
  const token = process.env.META_PAGE_ACCESS_TOKEN;
  if (!token) return;
  await fetch(`https://graph.facebook.com/v21.0/me/messages?access_token=${encodeURIComponent(token)}`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      recipient: { id: recipientId },
      messaging_type: "RESPONSE",
      message: { text }
    })
  });
}
app.post("/webhook", async (req, res) => {
  if (process.env.META_APP_SECRET && req.rawBody) {
    const signature = req.get("x-hub-signature-256") || "";
    const expected = "sha256=" + crypto.createHmac("sha256", process.env.META_APP_SECRET).update(req.rawBody).digest("hex");
    const a = Buffer.from(signature), b = Buffer.from(expected);
    if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) return res.sendStatus(401);
  }
  res.sendStatus(200);
  try {
    for (const entry of (req.body.entry || [])) {
      for (const event of (entry.messaging || [])) {
        const sender = event.sender && event.sender.id;
        const text = event.message && event.message.text;
        if (!sender || !text) continue;
        const command = text.trim().toLowerCase();
        if (command === `${settings.prefix}ping`) await sendMessage(sender, "Pong! DRIS BOT is online.");
        else if (command === `${settings.prefix}help`) await sendMessage(sender, `Commands: ${settings.prefix}ping, ${settings.prefix}help, ${settings.prefix}info`);
        else if (command === `${settings.prefix}info`) await sendMessage(sender, `${settings.botName} is running.`);
      }
    }
  } catch (err) { console.error("Webhook processing error:", err.message); }
});

app.get("*", (req, res) => res.sendFile(path.join(__dirname, "public", "index.html")));
app.listen(PORT, "0.0.0.0", () => console.log(`DRIS BOT HOST listening on ${PORT}`));
