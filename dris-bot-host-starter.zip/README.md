# DRIS BOT HOST

A starter dashboard and webhook server for a Facebook Page Messenger bot.

## Run locally
1. Install Node.js 20 or newer.
2. Copy `.env.example` to `.env` and change the admin password and secrets.
3. Run `npm install`, then `npm start`.
4. Open `http://localhost:3000`.

## Deploying
Deploy this repository as a Render Web Service. Build command: `npm install`. Start command: `npm start`. Add environment variables from `.env.example` in Render's Environment settings. Do not commit `.env` or paste tokens into public files.

## Meta Messenger setup
This starter uses the official Meta Messenger Platform for a Facebook Page. Configure a Meta app, Page access token, app secret, and webhook callback URL `https://YOUR-SERVICE.onrender.com/webhook`. Use the same `META_VERIFY_TOKEN` value in Meta and Render, and subscribe the Page to the required messaging webhook events. Meta app review/permissions may be required.

The included commands are `-ping`, `-help`, and `-info` (prefix configurable). This is a starter, not a complete production hosting platform. Before production use, configure a persistent session store, HTTPS (provided by host), secure secrets, logging, and appropriate Meta permissions.
