const login = document.querySelector("#login");
const dashboard = document.querySelector("#dashboard");
async function request(url, options={}) {
  const response = await fetch(url, {headers:{"Content-Type":"application/json"}, ...options});
  const data = await response.json().catch(()=>({}));
  if (!response.ok) throw new Error(data.error || "Request failed");
  return data;
}
function showDashboard(data) {
  login.hidden = true; dashboard.hidden = false;
  document.querySelector("#status").textContent = data.connected ? "Credentials added" : "Not connected";
  document.querySelector("#botLabel").textContent = data.settings.botName;
  const form = document.querySelector("#settingsForm");
  form.botName.value = data.settings.botName; form.prefix.value = data.settings.prefix; form.language.value = data.settings.language;
}
document.querySelector("#loginForm").addEventListener("submit", async e => {
  e.preventDefault(); const f = new FormData(e.target);
  try { await request("/api/login",{method:"POST",body:JSON.stringify({username:f.get("username"),password:f.get("password")})}); showDashboard(await request("/api/status")); }
  catch(err){document.querySelector("#loginError").textContent=err.message;}
});
document.querySelector("#settingsForm").addEventListener("submit", async e => {
  e.preventDefault(); const f=new FormData(e.target);
  try {const data=await request("/api/settings",{method:"POST",body:JSON.stringify({botName:f.get("botName"),prefix:f.get("prefix"),language:f.get("language")})}); document.querySelector("#saveMessage").textContent="Settings saved."; document.querySelector("#botLabel").textContent=data.settings.botName;}
  catch(err){document.querySelector("#saveMessage").textContent=err.message;}
});
document.querySelector("#logout").addEventListener("click",async()=>{await request("/api/logout",{method:"POST"});dashboard.hidden=true;login.hidden=false;});
