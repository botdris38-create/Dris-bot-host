# DRIS BOT HOST

A starter self-hosted dashboard for managing one Facebook Messenger Page bot through the official Meta Messenger Platform.

## What is included

- Dark purple responsive owner dashboard
- Admin login using environment variables
- Bot name, prefix and language settings
- Start/stop controls
- Meta webhook verification endpoint (`GET /webhook`)
- Incoming Page message webhook (`POST /webhook`)
- Basic `-ping`, `-help`, and `-info` commands
- Meta webhook signature validation when `META_APP_SECRET` is configured

## Important: this is a starter, not a one-click Facebook connection

This bot uses a Facebook **Page** and the official Messenger Platform. It does not log into a personal Facebook account, collect personal-account cookies, or use Appstate.

You need:
1. A Facebook Page that you manage.
2. A Meta for Developers app with Messenger configured.
3. A Page access token with the required Page messaging permissions.
4. A public HTTPS deployment URL.
5. A webhook subscription for the Page's `messages` field.

Meta's standard access in development mode is limited to people with an app role (admin, developer, tester) until the required review/access is approved. Messaging is subject to Meta's platform policies and allowed messaging windows.

## Run locally

Requires Node.js 20+.

```bash
npm install
cp .env.example .env
```

Edit `.env`:
- Set a long `ADMIN_PASSWORD`
- Set a long random `SESSION_SECRET`
- Set a random `VERIFY_TOKEN`
- For local dashboard testing, Meta credentials can remain blank.

Then run:

```bash
npm start
```

Open `http://localhost:3000`.

## Deploy

Deploy this folder to a Node.js host that supports:
- Node.js 20+
- Environment variables/secrets
- Persistent storage for `data/bot.json`
- A public HTTPS URL

Set the variables from `.env.example` in the host's secret/environment settings. Never upload `.env` or commit tokens to GitHub.

After deployment, your webhook URL is:

```text
https://YOUR-DOMAIN/webhook
```

Use the exact same `VERIFY_TOKEN` in your Meta webhook configuration and host environment.

## Meta setup outline

1. Go to https://developers.facebook.com/ and create an app.
2. Add the Messenger product/use case and connect your Facebook Page.
3. Generate a Page access token for the Page you manage.
4. Add `PAGE_ACCESS_TOKEN`, `META_APP_SECRET`, and `VERIFY_TOKEN` as host secrets.
5. Set the Meta webhook callback URL to `https://YOUR-DOMAIN/webhook`.
6. Subscribe to the `messages` webhook field and complete Page subscription.
7. Test with an account assigned an app role while the app is in development mode.

See Meta's official quick start:
https://developers.facebook.com/docs/messenger-platform/getting-started/quick-start

## Security notes

- Keep `.env` private. Never paste Page tokens or app secrets into chats.
- Use HTTPS in production.
- Change the default dashboard credentials before deploying.
- Use a persistent host volume for the `data/` folder.
- Add a production-grade session store before scaling beyond a single instance. The default Express MemoryStore is only suitable for a small starter/demo.
- This starter intentionally supports basic text commands only. Add features only within Meta's policies and user messaging permissions.
