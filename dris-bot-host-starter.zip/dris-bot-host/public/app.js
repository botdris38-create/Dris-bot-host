const $ = (selector) => document.querySelector(selector);
const loginView = $("#loginView");
const appView = $("#appView");
const toast = $("#toast");

function notify(message) {
  toast.textContent = message;
  toast.classList.add("show");
  setTimeout(() => toast.classList.remove("show"), 2800);
}
async function api(url, options = {}) {
  const response = await fetch(url, {
    credentials: "same-origin",
    headers: { "Content-Type": "application/json", ...(options.headers || {}) },
    ...options
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.error || "Request failed.");
  return data;
}
function showLogin() {
  loginView.classList.remove("hidden");
  appView.classList.add("hidden");
}
function showApp() {
  loginView.classList.add("hidden");
  appView.classList.remove("hidden");
  loadStatus();
}
function renderLogs(logs) {
  const el = $("#logs");
  if (!logs || !logs.length) {
    el.innerHTML = '<p class="muted">No activity yet.</p>';
    return;
  }
  el.innerHTML = logs.map(item => `<div class="log-row"><time>${new Date(item.time).toLocaleString()}</time><span>${escapeHtml(item.message)}</span></div>`).join("");
}
function escapeHtml(value) {
  return String(value).replace(/[&<>"']/g, c => ({ "&":"&amp;", "<":"&lt;", ">":"&gt;", '"':"&quot;", "'":"&#39;" }[c]));
}
async function loadStatus() {
  try {
    const data = await api("/api/status");
    const c = data.config;
    $("#botName").textContent = c.name;
    $("#botPrefix").textContent = `Prefix: ${c.prefix}`;
    $("#botStatus").textContent = c.enabled ? "● Running" : "● Stopped";
    $("#botStatus").className = `status ${c.enabled ? "running" : "stopped"}`;
    $("#runningCount").textContent = c.enabled ? "01" : "00";
    $("#connectionText").textContent = data.connected ? "Ready" : "Not set";
    $("#tokenCheck").textContent = data.connected ? "✓" : "○";
    $("#tokenCheck").classList.toggle("ok", data.connected);
    $("#secretCheck").textContent = data.webhookConfigured ? "✓" : "○";
    $("#secretCheck").classList.toggle("ok", data.webhookConfigured);
    $("#nameInput").value = c.name;
    $("#prefixInput").value = c.prefix;
    $("#languageInput").value = c.language;
    renderLogs(data.logs);
  } catch (error) {
    notify(error.message);
  }
}
$("#loginForm").addEventListener("submit", async (event) => {
  event.preventDefault();
  const form = new FormData(event.currentTarget);
  try {
    await api("/api/login", { method: "POST", body: JSON.stringify({
      username: form.get("username"), password: form.get("password")
    }) });
    $("#loginError").textContent = "";
    showApp();
  } catch (error) {
    $("#loginError").textContent = error.message;
  }
});
$("#logout").addEventListener("click", async () => {
  try { await api("/api/logout", { method: "POST", body: "{}" }); } catch {}
  showLogin();
});
$("#settingsForm").addEventListener("submit", async (event) => {
  event.preventDefault();
  const form = new FormData(event.currentTarget);
  try {
    await api("/api/settings", { method: "POST", body: JSON.stringify({
      name: form.get("name"), prefix: form.get("prefix"), language: form.get("language")
    }) });
    $("#saveMessage").textContent = "Saved successfully.";
    notify("Bot settings saved.");
    loadStatus();
  } catch (error) { notify(error.message); }
});
$("#startBtn").addEventListener("click", async () => {
  try { await api("/api/start", { method: "POST", body: "{}" }); notify("Bot enabled."); loadStatus(); }
  catch (error) { notify(error.message); }
});
$("#stopBtn").addEventListener("click", async () => {
  try { await api("/api/stop", { method: "POST", body: "{}" }); notify("Bot stopped."); loadStatus(); }
  catch (error) { notify(error.message); }
});
$("#refresh").addEventListener("click", loadStatus);
document.querySelectorAll("[data-open]").forEach(button => button.addEventListener("click", () => {
  $("#settingsPanel").scrollIntoView({ behavior: "smooth" });
}));
document.querySelectorAll(".nav").forEach(button => button.addEventListener("click", () => {
  document.querySelectorAll(".nav").forEach(n => n.classList.remove("active"));
  button.classList.add("active");
  const view = button.dataset.view;
  $("#crumb").textContent = view === "overview" ? "Overview" : view === "bot" ? "My Bot" : "Settings";
  if (view === "settings") $("#settingsPanel").scrollIntoView({ behavior: "smooth" });
  if (view === "bot") $(".bot-card").scrollIntoView({ behavior: "smooth" });
  if (view === "overview") window.scrollTo({ top: 0, behavior: "smooth" });
  $(".sidebar").classList.remove("open");
}));
$("#menu").addEventListener("click", () => $(".sidebar").classList.toggle("open"));

api("/api/me").then(data => data.authenticated ? showApp() : showLogin()).catch(showLogin);
