require("dotenv").config();

const express = require("express");
const session = require("express-session");
const helmet = require("helmet");
const crypto = require("crypto");
const fs = require("fs");
const path = require("path");

const app = express();
const PORT = Number(process.env.PORT || 3000);
const DATA_DIR = path.join(__dirname, "data");
const CONFIG_FILE = path.join(DATA_DIR, "bot.json");

fs.mkdirSync(DATA_DIR, { recursive: true });

const defaultConfig = {
  name: "DRIS",
  prefix: "-",
  language: "English",
  enabled: false,
  replies: {
    ping: "Pong! DRIS is online.",
    help: "Available commands: -ping, -help, -info"
  }
};

function readConfig() {
  try {
    if (fs.existsSync(CONFIG_FILE)) {
      return { ...defaultConfig, ...JSON.parse(fs.readFileSync(CONFIG_FILE, "utf8")) };
    }
  } catch (error) {
    console.error("Could not read bot config:", error.message);
  }
  return { ...defaultConfig };
}

let config = readConfig();
let recentLogs = [];

function log(message) {
  const item = { time: new Date().toISOString(), message: String(message).slice(0, 300) };
  recentLogs.unshift(item);
  recentLogs = recentLogs.slice(0, 50);
  console.log(`[${item.time}] ${item.message}`);
}

function saveConfig() {
  const temp = CONFIG_FILE + ".tmp";
  fs.writeFileSync(temp, JSON.stringify(config, null, 2), { mode: 0o600 });
  fs.renameSync(temp, CONFIG_FILE);
}

const required = ["ADMIN_USERNAME", "ADMIN_PASSWORD", "SESSION_SECRET", "VERIFY_TOKEN"];
const missing = required.filter((key) => !process.env[key]);
if (missing.length) {
  console.warn("Missing environment variables:", missing.join(", "));
}

app.set("trust proxy", 1);
app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      styleSrc: ["'self'", "'unsafe-inline'", "https://fonts.googleapis.com"],
      fontSrc: ["'self'", "https://fonts.gstatic.com"],
      scriptSrc: ["'self'"],
      imgSrc: ["'self'", "data:"],
      connectSrc: ["'self'"]
    }
  }
}));
app.use(express.json({ limit: "1mb" }));
app.use(express.urlencoded({ extended: false, limit: "20kb" }));
app.use(session({
  name: "dris.sid",
  secret: process.env.SESSION_SECRET || "development-only-change-me",
  resave: false,
  saveUninitialized: false,
  cookie: {
    httpOnly: true,
    sameSite: "strict",
    secure: process.env.NODE_ENV === "production",
    maxAge: 1000 * 60 * 60 * 8
  }
}));

function requireLogin(req, res, next) {
  if (req.session && req.session.authenticated) return next();
  return res.status(401).json({ error: "Please log in first." });
}

app.get("/health", (_req, res) => res.json({ ok: true, service: "DRIS BOT HOST" }));

app.post("/api/login", (req, res) => {
  const username = String(req.body.username || "");
  const password = String(req.body.password || "");
  const expectedUser = process.env.ADMIN_USERNAME || "";
  const expectedPass = process.env.ADMIN_PASSWORD || "";

  const userOk = username === expectedUser;
  const passOk = password.length === expectedPass.length &&
    crypto.timingSafeEqual(Buffer.from(password), Buffer.from(expectedPass));

  if (!expectedUser || !expectedPass || !userOk || !passOk) {
    return res.status(401).json({ error: "Incorrect username or password." });
  }

  req.session.authenticated = true;
  return res.json({ ok: true });
});

app.post("/api/logout", requireLogin, (req, res) => {
  req.session.destroy(() => res.json({ ok: true }));
});

app.get("/api/me", (req, res) => {
  res.json({ authenticated: Boolean(req.session && req.session.authenticated) });
});

app.get("/api/status", requireLogin, (_req, res) => {
  res.json({
    config: {
      name: config.name,
      prefix: config.prefix,
      language: config.language,
      enabled: config.enabled
    },
    connected: Boolean(process.env.PAGE_ACCESS_TOKEN),
    webhookConfigured: Boolean(process.env.VERIFY_TOKEN && process.env.META_APP_SECRET),
    logs: recentLogs
  });
});

app.post("/api/settings", requireLogin, (req, res) => {
  const name = String(req.body.name || "").trim().slice(0, 40);
  const prefix = String(req.body.prefix || "").trim().slice(0, 5);
  const language = String(req.body.language || "English");

  if (!name || !prefix) return res.status(400).json({ error: "Bot name and prefix are required." });
  if (!["English", "Filipino"].includes(language)) {
    return res.status(400).json({ error: "Unsupported language." });
  }

  config.name = name;
  config.prefix = prefix;
  config.language = language;
  saveConfig();
  log("Bot settings saved.");
  res.json({ ok: true });
});

app.post("/api/start", requireLogin, (_req, res) => {
  if (!process.env.PAGE_ACCESS_TOKEN) {
    return res.status(400).json({ error: "Add PAGE_ACCESS_TOKEN in your host secrets before starting the Messenger bot." });
  }
  config.enabled = true;
  saveConfig();
  log("Bot enabled.");
  res.json({ ok: true });
});

app.post("/api/stop", requireLogin, (_req, res) => {
  config.enabled = false;
  saveConfig();
  log("Bot stopped.");
  res.json({ ok: true });
});

// Meta webhook verification (GET)
app.get("/webhook", (req, res) => {
  const mode = req.query["hub.mode"];
  const token = req.query["hub.verify_token"];
  const challenge = req.query["hub.challenge"];

  if (mode === "subscribe" && token === process.env.VERIFY_TOKEN && challenge) {
    log("Meta webhook verified.");
    return res.status(200).send(String(challenge));
  }
  return res.sendStatus(403);
});

function validMetaSignature(req) {
  const appSecret = process.env.META_APP_SECRET;
  if (!appSecret) return process.env.NODE_ENV !== "production"; // allow local setup only
  const signature = req.get("x-hub-signature-256") || "";
  if (!signature.startsWith("sha256=")) return false;

  const expected = "sha256=" + crypto
    .createHmac("sha256", appSecret)
    .update(req.rawBody)
    .digest("hex");

  const a = Buffer.from(signature);
  const b = Buffer.from(expected);
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}

// Capture raw request bytes for Meta signature verification.
app.use("/webhook", express.json({
  verify: (req, _res, buf) => { req.rawBody = Buffer.from(buf); },
  limit: "1mb"
}));

async function sendMessengerText(psid, text) {
  const token = process.env.PAGE_ACCESS_TOKEN;
  if (!token) {
    log("Cannot send: PAGE_ACCESS_TOKEN is not configured.");
    return;
  }

  const version = process.env.GRAPH_API_VERSION || "v27.0";
  const endpoint = `https://graph.facebook.com/${version}/me/messages?access_token=${encodeURIComponent(token)}`;

  const response = await fetch(endpoint, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      recipient: { id: psid },
      messaging_type: "RESPONSE",
      message: { text: String(text).slice(0, 2000) }
    })
  });

  const result = await response.json().catch(() => ({}));
  if (!response.ok) {
    log(`Meta Send API error ${response.status}: ${JSON.stringify(result).slice(0, 180)}`);
  } else {
    log("Messenger reply sent.");
  }
}

async function handleIncomingMessage(event) {
  const psid = event && event.sender && event.sender.id;
  const text = event && event.message && event.message.text;
  if (!psid || typeof text !== "string" || !config.enabled) return;

  const trimmed = text.trim();
  const prefix = config.prefix;
  if (!trimmed.startsWith(prefix)) return;

  const command = trimmed.slice(prefix.length).trim().split(/\s+/)[0].toLowerCase();
  if (command === "ping") {
    await sendMessengerText(psid, config.replies.ping);
  } else if (command === "help") {
    await sendMessengerText(psid, config.replies.help.replaceAll("-", prefix));
  } else if (command === "info") {
    await sendMessengerText(psid, `${config.name} Messenger bot is running.`);
  }
}

app.post("/webhook", async (req, res) => {
  if (!validMetaSignature(req)) {
    log("Rejected webhook: invalid Meta signature.");
    return res.sendStatus(403);
  }

  const body = req.body;
  if (!body || body.object !== "page") return res.sendStatus(404);

  // Acknowledge quickly; process events asynchronously.
  res.status(200).send("EVENT_RECEIVED");

  for (const entry of body.entry || []) {
    for (const event of entry.messaging || []) {
      handleIncomingMessage(event).catch((error) => log(`Message handler error: ${error.message}`));
    }
  }
});

app.use(express.static(path.join(__dirname, "public")));

app.listen(PORT, "0.0.0.0", () => {
  log(`DRIS BOT HOST listening on port ${PORT}`);
});
